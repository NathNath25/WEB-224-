// Import necessary modules
const WebSocket = require('ws');
const express = require("express");
const http = require("http");

// Initialize Express app and HTTP server
const app = express();
const server = http.createServer(app);

// Initialize WebSocket server on the HTTP server
const ws_server = new WebSocket.Server({ server });

// Data structures to store users and rooms
const users = {}
const rooms = {}

// Handle new WebSocket connections
ws_server.on("connection", (conn) => {
    // Handle incoming messages from clients
    conn.on("message", (message) => {
        const parse_message = JSON.parse(message);
        switch(parse_message.action){
            case "login":
                login_user(parse_message, conn);
                break;
            case "create":
                createRoom(parse_message.room, conn);
                break;
            case "join":
                joinRoom(parse_message.room, conn);
                break;
            case "time":
                fetch_timezone_data(parse_message.continent, parse_message.capital, conn);
                console.log(parse_message);
                break;
            case "holiday":
                get_country(parse_message.country, conn);
                break;
            case "create-task":
                createTask(parse_message.task, parse_message.deadline, conn);
        }
    });
});

// Fetch timezone data from the World Time API
async function fetch_timezone_data(continent, capital, conn) {
    try {
        let continent_time = continent.split(" ").join("%20");
        let capital_time = capital.split(" ").join("%20");
        const api_url = `http://worldtimeapi.org/api/timezone/${continent_time}/${capital_time}`;

        const response = await fetch(api_url);
        if (!response.ok) {
            console.log("wrong");
            conn.send(JSON.stringify({ error: "Failed to fetch time data" }));
            return;
        }

        const data = await response.json();
        console.log(data);

        conn.send(JSON.stringify({ data: data, action: "fetchTimeData" }));

    } catch (error) {
        console.log(error);
        conn.send(JSON.stringify({ error: error.message }));
    }
}

// Handle user login
function login_user(data, conn) {
    users[data.id] = { "id": data.id, "user": data.user, "conn": data.conn, "timezone": data.timezone };
    conn.user = data.user;
    conn.id = data.id;
    conn.timezone = data.timezone;
    broadcastRoomList();
}

// Create a new room
function createRoom(room, conn) {
    if (rooms[room]) {
        return;
    }
    rooms[room] = [];
    rooms[room].push(conn);
    joinRoom(room, conn);
    console.log(rooms);
    broadcastRoomList();
}

// Create a task and broadcast to all clients
function createTask(task, deadline) {
    const message = JSON.stringify({
        message: `${task} is due ${deadline}`,
        action: 'task'
    });
    ws_server.clients.forEach(client => {
        if (client.readyState == WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// Join an existing room
function joinRoom(room, conn) {
    if (rooms[conn.room]) {
      rooms[conn.room] = rooms[conn.room].filter((client) => client !== conn);
    }

    if (!rooms[room].includes(conn)) {
        rooms[room].push(conn);
    }
    conn.room = room;
    broadcastRoomMembers(room);
}

// Broadcast the list of rooms to all clients
function broadcastRoomList() {
    const message = JSON.stringify({
        rooms: Object.keys(rooms),
        action: "updateRoomList"
    });
    ws_server.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// Broadcast the list of members in a room to all clients in the room
function broadcastRoomMembers(room) {
    const message = JSON.stringify({
        room: room,
        members: rooms,
        action: "updateRoomMembers"
    });
    rooms[room].forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

// Fetch the list of countries and their codes
async function get_country(data, conn) {
    try {
        const year = new Date();
        const country_url = "https://date.nager.at/api/v3/AvailableCountries";

        const country_resp = await fetch(country_url);
        if (!country_resp.ok) {
            console.log("wrong");
            conn.send(JSON.stringify({ error: "Failed to fetch time data" }));
            return;
        }
        const country_data = await country_resp.json();
        for (let i = 0; i < country_data.length; i++) {
            if (data == country_data[i].name) {
                console.log(data, country_data[i].countryCode, year.getFullYear());
                get_holiday(country_data[i].countryCode, year.getFullYear(), conn);
            }
        }
    } catch (error) {
        console.log(error);
        conn.send(JSON.stringify({ error: error.message }));
    }
}

// Fetch the list of holidays for a given country and year
async function get_holiday(country_code, year, conn) {
    try {
        let holiday_date = [];
        let holiday_name = [];
        const holiday_url = `https://date.nager.at/api/v3/PublicHolidays/${year}/${country_code}`;

        const holiday_resp = await fetch(holiday_url);
        if (!holiday_resp.ok) {
            console.log("wrong");
            conn.send(JSON.stringify({ error: "Failed to fetch country code" }));
            return;
        }

        const holiday_data = await holiday_resp.json();
        for (let i = 0; i < holiday_data.length; i++) {
            console.log(holiday_data[i]);
            holiday_date.push(holiday_data[i].date);
            holiday_name.push(holiday_data[i].name);
        }

        conn.send(JSON.stringify({
            holiday_date: holiday_date,
            holiday_name: holiday_name,
            action: "fetchHolidayData"
        }));

    } catch (error) {
        console.log(error);
        conn.send(JSON.stringify({ error: error.message }));
    }
}

// Start the server on port 8080
server.listen(8080, () => {
    console.log("8080");
});
