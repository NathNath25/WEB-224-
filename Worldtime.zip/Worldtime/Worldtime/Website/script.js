// Establish a WebSocket connection to the server
const conn = new WebSocket('ws://localhost:8080');

// Get references to various HTML elements
const home = document.getElementById('home-content');
const loginPage = document.getElementById('login-container');
const mainPage = document.getElementById('main-container');
const convert_time = document.getElementById('convert-time-content');
const create_room = document.getElementById('create-room-content');
const room_field = document.getElementById('room-field');
const room_container = document.getElementById('room-container');
const holiday_container = document.getElementById('holiday-content');
const rooms_list = document.getElementById('rooms-list-container');
let user, id;

// Handle incoming WebSocket messages
conn.addEventListener("message", (message) => {
    const parse_message = JSON.parse(message.data);
    switch(parse_message.action){
        // Update room list
        case "updateRoomList" :
            const rooms = parse_message.rooms;
            updateRoomList(rooms);
            break;
        // Display time data
        case "fetchTimeData":
            if (parse_message.error) {
                alert(parse_message.error);
            } else {
                display_time_data(parse_message.data);
            }
            break;
        // Update room members
        case "updateRoomMembers":
            if (parse_message.room === document.getElementById('room-name').innerText) {
                updateRoomMembers(parse_message.members);
            }
            break;
        // Display holiday data
        case "fetchHolidayData":
            if (parse_message.error) {
                alert(parse_message.error)
            } else {
                display_holiday(parse_message.holiday_date, parse_message.holiday_name)
            }
            break;
        // Display task data
        case "task":
            display_task(parse_message.message)
    }

    // Handle errors
    switch(parse_message.error){
        case "No country code":
            break;
    }
});

// Add event listeners to input fields for button state toggling
document.getElementById('capital').addEventListener('input', toggleButtonState);
document.getElementById('continent').addEventListener('change', toggleButtonState);

// Toggle the button state based on input fields
function toggleButtonState() {
    const capital = document.getElementById('capital').value;
    const btn = document.getElementById('btn');
    btn.disabled = capital.trim() === "";
}

// Send time data to the server
function send_time() {
    const time = JSON.stringify({
        continent: document.getElementById('continent').value,
        capital: document.getElementById("capital").value,
        action: 'time'
    });
    conn.send(time);
}

// Send holiday data to the server
function send_holiday() {
    const holiday = JSON.stringify({
        country: document.getElementById("country-search").value,
        action: 'holiday'
    });
    conn.send(holiday);
}

// Display time data on the page
function display_time_data(data) {
    const timezoneContainers = document.getElementsByClassName('timezone');
    const timezoneText = `Current time in ${data.timezone}:`;

    // Check if the timezone is already displayed
    for (let i = 0; i < timezoneContainers.length; i++) {
        if (timezoneContainers[i].innerText.includes(timezoneText)) {
            alert('This timezone is already added.');
            return;
        }
    }
    // Add the new timezone data
    for (let i = 0; i < timezoneContainers.length; i++) {
        if (!timezoneContainers[i].innerHTML) {
            timezoneContainers[i].innerHTML = `
                <p>${timezoneText}</p>
                <div class="clock-delete">
                    <div class="clock" id="clock${i}"></div>
                    <button onclick="delete_timezone(${i})" id="delete-btn">Delete</button>
                </div>
            `;
            startClock(data.timezone, `clock${i}`);
            break;
        }
    }
}

// Display holiday data on the page
function display_holiday(dates, names) {
    let holidayList = document.getElementById('holiday-list');
    holidayList.innerHTML = ''; 
    
    // Create and append holiday cards
    for(let i = 0; i < dates.length; i++) {
        let card = document.createElement('div');
        card.className = 'holiday-card';
        
        let dateElem = document.createElement('p');
        dateElem.textContent = `Date: ${dates[i]}`;
        card.appendChild(dateElem);
        
        let nameElem = document.createElement('p');
        nameElem.textContent = `Holiday: ${names[i]}`;
        card.appendChild(nameElem);
        
        holidayList.appendChild(card);
    }
}

// Display a task message on the page
function display_task(message) {
    const tasksList = document.getElementById('tasks-list');
    
    const taskElement = document.createElement('div');
    taskElement.className = 'task-item';
    taskElement.innerText = message;
    
    tasksList.appendChild(taskElement);
}

// Delete a timezone from the display
function delete_timezone(index) {
    const timezoneContainer = document.getElementsByClassName('timezone')[index];
    timezoneContainer.innerHTML = '';
    localStorage.removeItem(`timezone${index}`);
}

// Start the clock for a timezone
function startClock(timezone, clockId) {
    const clockElement = document.getElementById(clockId);

    function updateClock() {
        const now = new Date();
        const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: timezone,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: document.getElementById('toggle').checked
        });
        clockElement.innerText = formatter.format(now);
    }

    setInterval(updateClock, 1000);
    updateClock(); 
}

// Handle login process
function login() {
    user = document.getElementById('name').value;
    id = document.getElementById('id').value;
    continent = document.getElementById('continent').value;
    country = document.getElementById('country').value;
    capital = document.getElementById('capital').value;
    document.getElementById('username').textContent = user;
    document.getElementById('user-id').textContent = id;
    document.getElementById('timezone').textContent = capital + ", " + continent;
    document.getElementById('usernameSpan').textContent = user;
    loginPage.style.display = 'none';
    mainPage.style.display = 'block';
    const message = JSON.stringify({
        id: id,
        user: user,
        timezone: continent+"/"+capital,
        action: "login"
    });
    conn.send(message);
    showHome();
}

// Create a new room
function createRoom(){
    const room = document.getElementById('room').value;
    const category = document.getElementById('category').value;
    const date = document.getElementById('deadline-date').value;
    const time = document.getElementById('deadline-time').value;
    const deadline = `${date}T${time}`;
    const message = JSON.stringify({
        room: room,
        category: category,
        deadline: deadline,
        action: "create"
    });
    console.log(message);
    conn.send(message);
    joinRoom(room);
}

// Create a new task
function createTask(){
    const task = document.getElementById('task').value;
    const date = document.getElementById('task-deadline-date').value;
    const time = document.getElementById('task-deadline-time').value;
    const deadline = `${date}T${time}`;
    const message = JSON.stringify({
        task: task,
        deadline: deadline,
        action: "create-task"
    });
    console.log(message);
    conn.send(message);
}

// Update the room list
function updateRoomList(rooms) {
    if (!rooms) return;

    const roomsList = document.getElementById('rooms-list');
    roomsList.innerHTML = '';
    
    // Create and append room items
    rooms.forEach(room => {
        const roomItem = document.createElement('div');
        roomItem.className = 'room-item';
        roomItem.innerHTML = `
            <h4>${room}</h4>
            <button class="join-room-btn" onclick="joinRoom('${room}')">Join</button>
        `;
        roomsList.appendChild(roomItem);
    });
}

// Join an existing room
function joinRoom(room){
    const message = JSON.stringify({
        room: room,
        action: "join"
    });
    conn.send(message);
    showCreateRoom();
    room_field.style.display = 'none';
    room_container.style.display = 'block';
    document.getElementById('room').value = "";
    document.getElementById('room-name').innerHTML = room;
}

// Update the list of room members
function updateRoomMembers(members) {
    const membersList = document.getElementById('room-members-list');
    membersList.innerHTML = '';

    // Create and append member items
    for (const room in members) {
        if (members.hasOwnProperty(room)) {
            const roomMembers = members[room];
            
            roomMembers.forEach(member => {
                const memberItem = document.createElement('div');
                memberItem.className = 'room-member';

                const userName = document.createElement('p');
                userName.textContent = 'Name: ' + member.user;
                memberItem.appendChild(userName);

                const userID = document.createElement('p');
                userID.textContent = 'ID: ' + member.id;
                memberItem.appendChild(userID);

                const userTimezone = document.createElement('p');
                userTimezone.textContent = 'Timezone: ' + member.timezone;
                memberItem.appendChild(userTimezone);

                membersList.appendChild(memberItem);
            });
        }
    }
}

// Show the home page
function showHome() {
    home.style.display = 'block';
    convert_time.style.display = 'none';
    create_room.style.display = 'none';
    rooms_list.style.display = 'block';
    holiday_container.style.display = 'none';
}

// Show the convert time page
function showConvertTime() {
    home.style.display = 'none';
    convert_time.style.display = 'block';
    create_room.style.display = 'none';
    rooms_list.style.display = 'none';
}

// Show the create room page
function showCreateRoom() {
    home.style.display = 'none';
    convert_time.style.display = 'none';
    room_container.style.display = 'none';
    room_field.style.display = 'block';
    create_room.style.display = 'block';
    holiday_container.style.display = 'none';
}

// Show the holiday page
function showHolidays() {
    home.style.display = 'none';
    convert_time.style.display = 'none';
    create_room.style.display = 'none';
    holiday_container.style.display = 'block';
}

// Initial button state toggle
toggleButtonState();
